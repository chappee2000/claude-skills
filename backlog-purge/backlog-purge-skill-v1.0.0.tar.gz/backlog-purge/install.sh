#!/bin/bash
# Backlog Purge Skill Installer
# Version 1.0.0

set -e

SKILL_NAME="backlog-purge"
INSTALL_DIR="${HOME}/.claude/skills/${SKILL_NAME}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "📦 Backlog Purge Skill Installer"
echo "================================="
echo ""

# Check if Claude Code is installed
if ! command -v claude &> /dev/null; then
    echo "⚠️  Warning: Claude Code CLI not found in PATH"
    echo "   You can still install the skill, but make sure Claude Code is installed."
    echo "   Download: https://claude.ai/code"
    echo ""
    read -p "Continue anyway? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Check if skill directory exists
if [ -d "$INSTALL_DIR" ]; then
    echo "⚠️  Skill already installed at: $INSTALL_DIR"
    echo ""
    read -p "Overwrite existing installation? (y/N) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "❌ Installation cancelled"
        exit 1
    fi
    echo "📁 Backing up existing skill to ${INSTALL_DIR}.backup"
    mv "$INSTALL_DIR" "${INSTALL_DIR}.backup"
fi

# Create skills directory if it doesn't exist
mkdir -p "${HOME}/.claude/skills"

# Copy skill files
echo "📋 Installing skill files..."
cp -r "$SCRIPT_DIR" "$INSTALL_DIR"

# Remove install script from installed skill
rm -f "${INSTALL_DIR}/install.sh"

# Verify installation
if [ -f "${INSTALL_DIR}/skill.md" ]; then
    echo ""
    echo "✅ Installation successful!"
    echo ""
    echo "📁 Installed to: $INSTALL_DIR"
    echo ""
    echo "📖 Next steps:"
    echo "   1. Read the quick start guide:"
    echo "      cat ~/.claude/skills/backlog-purge/QUICKSTART.md"
    echo ""
    echo "   2. In Claude Code, type: /backlog-purge"
    echo ""
    echo "   3. For full documentation:"
    echo "      cat ~/.claude/skills/backlog-purge/README.md"
    echo ""

    # Show version
    if [ -f "${INSTALL_DIR}/VERSION" ]; then
        echo "📌 Installed version:"
        cat "${INSTALL_DIR}/VERSION" | head -1
    fi
else
    echo "❌ Installation failed: skill.md not found"
    exit 1
fi
