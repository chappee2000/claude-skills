# Backlog Purge Skill - Installation Instructions

## TL;DR - Quick Install

```bash
# Extract and run installer
tar -xzf backlog-purge-skill.tar.gz
cd backlog-purge/
./install.sh
```

**That's it!** The skill is now available as `/backlog-purge` in Claude Code.

---

## About Claude Code Skills

**Important:** Claude Code skills are **directories with a `skill.md` file**, NOT `.skill` files.

```
Correct format:
  ~/.claude/skills/backlog-purge/
  └── skill.md  ← Required file

NOT a format:
  ~/.claude/skills/backlog-purge.skill  ← Doesn't exist
```

The `.tar.gz` package is just a compressed archive that extracts to the correct directory structure.

---

## Installation Methods

### Method 1: Install Script (Recommended) ⭐

```bash
# Extract the package
tar -xzf backlog-purge-skill.tar.gz
cd backlog-purge/

# Run installer
./install.sh
```

**What it does:**
- ✅ Checks for Claude Code CLI
- ✅ Creates `~/.claude/skills/` directory if needed  
- ✅ Backs up existing installation (if found)
- ✅ Copies all skill files to `~/.claude/skills/backlog-purge/`
- ✅ Verifies installation
- ✅ Shows next steps

**Example output:**
```
✅ Installation successful!

📁 Installed to: ~/.claude/skills/backlog-purge

📖 Next steps:
   1. Read: cat ~/.claude/skills/backlog-purge/QUICKSTART.md
   2. In Claude Code, type: /backlog-purge
```

### Method 2: Manual Install

```bash
# Extract directly to Claude skills directory
tar -xzf backlog-purge-skill.tar.gz -C ~/.claude/skills/

# Verify installation
ls ~/.claude/skills/backlog-purge/skill.md
# Should show the file path
```

### Method 3: One-Line Install

```bash
mkdir -p ~/.claude/skills && tar -xzf backlog-purge-skill.tar.gz -C ~/.claude/skills/
```

---

## What Gets Installed

```
~/.claude/skills/backlog-purge/
├── skill.md              # Skill definition (required by Claude Code)
├── README.md             # Comprehensive documentation (15KB)
├── QUICKSTART.md         # Quick start checklist (5.4KB)
├── FEATURES.md           # Feature list & capabilities (7.5KB)
├── cycle_time_insights.md # Example velocity report (3.8KB)
└── VERSION               # Version info (v1.0.0)
```

**Note:** `install.sh` is removed after installation (not needed in installed skill).

---

## Prerequisites

### 1. Claude Code CLI
**Required:** Claude Code must be installed.

**Check if installed:**
```bash
claude --version
```

**If not installed:**
- Download: https://claude.ai/code
- Or via Homebrew: `brew install claude`

### 2. Jira Access (For Using the Skill)
You'll need (when you run the skill, not for installation):
- Jira Personal Access Token (PAT)
- Read permissions on your team's Jira project
- Create filter permissions (for auto-filter creation)

---

## Verification

After installation:

```bash
# Check files installed
ls -la ~/.claude/skills/backlog-purge/

# Verify skill.md exists
cat ~/.claude/skills/backlog-purge/skill.md | head -5

# In Claude Code, type:
/backlog-purge
# Skill should appear and prompt for inputs
```

---

## Upgrading

```bash
# Extract new version
tar -xzf backlog-purge-skill-v2.0.0.tar.gz
cd backlog-purge/

# Run installer (will backup existing)
./install.sh

# Verify new version
cat ~/.claude/skills/backlog-purge/VERSION
```

---

## Uninstallation

```bash
rm -rf ~/.claude/skills/backlog-purge
```

---

## Troubleshooting

### Skill not appearing in Claude Code

```bash
# 1. Check skill.md exists
ls ~/.claude/skills/backlog-purge/skill.md

# 2. Restart Claude Code

# 3. Check frontmatter in skill.md
head -10 ~/.claude/skills/backlog-purge/skill.md
```

### Permission denied during install

```bash
chmod -R u+w ~/.claude/skills/
./install.sh
```

### Install script won't execute

```bash
chmod +x install.sh
./install.sh
```

---

## Getting Started

After installation:

```bash
# Quick start (read this first!)
cat ~/.claude/skills/backlog-purge/QUICKSTART.md

# Full documentation
cat ~/.claude/skills/backlog-purge/README.md

# Feature list
cat ~/.claude/skills/backlog-purge/FEATURES.md
```

---

## License

Built for backlog hygiene at scale. Free to use and modify.
