# Backlog Purge - Cycle Time Analysis

## Key Findings

### Velocity (Last 6 Months)
- **Actual completion rate:** 50 items/month (11.5 items/week)
- **April 2026:** 84 items completed (spike month)
- **March 2026:** 16 items completed

### Cycle Time Statistics
- **Mean:** 69.3 days
- **Median:** 20 days (this is your realistic planning number)
- **Distribution:**
  - Same day: 24% (fast-turnaround items)
  - 1-30 days: 40% (normal flow)
  - 31-90 days: 22% (slower items)
  - 91-180 days: 3%
  - **>180 days: 11%** ⚠️ These are outliers/blocked items

### By Issue Type (Avg Cycle Time)
- **Epic:** 223 days (10 items) - Very long
- **Story:** 56 days (59 items) - Primary work type
- **Bug:** 52 days (25 items) - Similar to stories
- **Task:** 15 days (5 items) - Fast
- **Vulnerability:** 33 days (1 item) - Small sample

### By Priority
- **Critical:** 210 days (10 items) - Counterintuitively SLOW
- **Major:** 220 days (5 items) - Also very slow
- **Normal:** 44 days (85 items) - Much faster

## Capacity Projections

### Current State
- **Backlog size:** 249 items
- **Team size:** 7 people

### Velocity-Based Capacity (50 items/month)
- **2 quarters (6 months):** ~300 items
- **Current backlog:** 249 items
- ⚠️ **CONCLUSION:** Backlog is actually UNDER capacity at current velocity

### BUT: Median Cycle Time Reality Check
- **Median cycle time:** 20 days
- **Team parallelization:** 7 people
- **Realistic 2-quarter capacity:** ~200-250 items
- **Recommendation:** Keep backlog at 200-250 items, but PURGE OLD/STALE items

## Insights That Should Inform Purge Criteria

### 1. **Age vs. Completion Probability**
Items >180 days old represent only 11% of completions but have MUCH longer cycle times.

**Purge Rule:** Items >180 days old with no recent activity are HIGHLY unlikely to ever be completed.

### 2. **Critical/Major Priority Paradox**
Critical and Major items take 4-5x longer than Normal priority (210 vs 44 days).

**Purge Rule:** High-priority items that are >1 year old and still not started are either:
- Mis-prioritized (should be lowered)
- Blocked permanently (should be closed or re-scoped)

### 3. **Epic Cycle Time is Extreme**
Epics take 223 days on average - nearly a year.

**Purge Rule:** Epics >1 year old with no child work OR all children on closure list should be reviewed for closure.

### 4. **The Team IS Highly Effective**
50 items/month is excellent velocity for a 7-person team.

**Purge Focus:** Don't purge for capacity reasons - purge for FOCUS and RELEVANCE. The team can handle the volume, but they shouldn't waste time on old, irrelevant work.

## Revised Purge Strategy

### Target: Purge ~50 items (20%) to maintain quality, not reduce quantity

Focus on:
1. **Stale work** (>180 days, no activity in 90 days) - 11% of items are in this category
2. **Blocked Critical/Major** (high priority, >1 year, never started) - clear blockers
3. **Empty or stalled Epics** (>1 year, no children or all children on purge list)
4. **Past due dates** (saved from previous purge, deadline passed)
5. **Duplicates** (poor hygiene cleanup)

### Velocity-Adjusted Closure Scoring

Update the scoring to reflect:
- Items >180 days old: High closure score (team rarely completes these)
- Critical/Major >365 days: Very high closure score (paradox suggests permanent blocker)
- Epics >365 days with no children: High closure score
- Items with cycle time >2x median for their type: Flag for review

## Recommendation

**Don't aim to reduce backlog to 136 items.**

Instead:
- Purge ~50-80 items (20-32%) to remove STALE, BLOCKED, and IRRELEVANT work
- Keep backlog at ~170-200 items (healthy 4-6 month pipeline at current velocity)
- Focus purge on QUALITY (removing clutter) not QUANTITY (arbitrary reduction)

The team's velocity suggests they can handle the current backlog size - the issue is likely that old items are cluttering up prioritization discussions.
